
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn.neural_network import MLPClassifier
import sklearn.metrics



def plot_decision_surface(classifier, x, labels, ax=None, colors=None, n=50, alpha=0.3, marker_size=200, marker_alpha=0.9):
    nlabels   = np.unique( labels ).size
    colors    = plt.cm.viridis( np.linspace(0,1,nlabels) )  if (colors is None) else colors
    ax        = plt.gca() if (ax is None) else ax
    xmin,xmax = x.min(axis=0), x.max(axis=0)
    Xp,Yp     = np.meshgrid( np.linspace(xmin[0],xmax[0],n) , np.linspace(xmin[1],xmax[1],n) )
    xp        = np.vstack( [Xp.flatten(), Yp.flatten()] ).T
    labelsp   = classifier.predict(xp)
    Labelsp   = np.reshape(labelsp, Xp.shape)
    cmap      = ListedColormap(colors)
    for i,label in enumerate( np.unique(labels) ):
        xx   = x[labels==label]
        ax.scatter( xx[:,0], xx[:,1], color=colors[i], s=marker_size, alpha=marker_alpha, label=f'Quality = {label}' )
    plt.pcolormesh(Xp, Yp, Labelsp, cmap=cmap, alpha=alpha, shading='nearest')
    ax.set_xlabel('Acidity')
    ax.set_ylabel('Citric')
    ax.legend()
    
def mlp_classification_quality_3_vs_8( data ):
	a       = data['acidity']
	c       = data['citric']
	q       = data['quality']
	

	# Assemble these variables into clear variable names for machine learning:
	x       = np.vstack( [a, c] ).T  # features matrix
	labels  = q                      # labels vetor


	# Extract only low quality (3) and high quality (8) wines
	i       = (q==3) | (q==8)
	x       = x[i]
	labels  = labels[i]


	# Train an MLP classifier and predict the values:
	mlp         = MLPClassifier(solver='lbfgs', alpha=0.01, hidden_layer_sizes=(40, 20), random_state=1)
	mlp.fit(x, labels)
	labels_pred = mlp.predict(x)


	# Calculate the classifier performance:
	cr      = sklearn.metrics.accuracy_score(labels, labels_pred)
	print( f'Classification rate = {cr}' )
	print()
	print()
	print()


	# Plot results:
	plt.figure()
	plot_decision_surface(mlp, x, labels, colors=['b','r'])
	plt.title('Figure 3:  Classification of low- vs high-quality wines.')
	plt.show()

