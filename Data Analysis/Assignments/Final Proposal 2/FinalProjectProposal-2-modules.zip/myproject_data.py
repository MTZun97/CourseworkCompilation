
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd




def load_data():
	df      = pd.read_csv( 'winequality-red.csv', delimiter=';' )
	acidity = df['fixed acidity']   # first feature
	citric  = df['citric acid']     # second feature
	quality = df['quality']         # target variable
	a       = np.asarray( acidity )
	c       = np.asarray( citric )
	q       = np.asarray( quality )
	data    = dict(acidity=a, citric=c, quality=q)
	return data


def plot_general_relationships( data ):
	a       = data['acidity']
	c       = data['citric']
	q       = data['quality']
	
	# Plot:
	fig,axs = plt.subplots( 1, 2, figsize=(8,3), tight_layout=True )
	ax0,ax1 = axs
	ax0.plot( a, q, 'bo')
	ax1.plot( c, q, 'ro')

	ax0.set_xlabel('Acidity')
	ax1.set_xlabel('Citric')
	ax0.set_ylabel('Quality')
	plt.suptitle('Figure 1:  General IV and DV relationships.')
	plt.show()