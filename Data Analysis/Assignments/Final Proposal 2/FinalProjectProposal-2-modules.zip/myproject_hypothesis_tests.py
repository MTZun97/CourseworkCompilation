
from scipy import stats
from matplotlib import pyplot as plt



def ttest_quality_3_vs_8(data):
	a       = data['acidity']
	q       = data['quality']
	
	# get acidity values for quality=3 and quality= 8:
	i0,i1   = q==3, q==8
	a0,a1   = a[ i0 ], a[ i1 ]

	# conduct test and report results:
	t,p     = stats.ttest_ind(a1, a0)
	print( 'Two-sample test results:' )
	print( f'  t = {t:.03f}' )
	print( f'  p = {p:.03f}' )
	print()
	print()

	# plot bar graph:
	m0,m1   = a0.mean(), a1.mean()
	s0,s1   = a0.std(ddof=1), a1.std(ddof=1)

	plt.figure(figsize=(8,6))
	ax      = plt.axes()
	x,y,e   = [0, 1], [m0,m1], [s0,s1]
	ax.bar( x , y )
	ax.errorbar( x , y , yerr=e , linestyle='none' )
	plt.setp(ax, xticks=x, xticklabels=['Quality = 3', 'Quality = 8'])
	ax.set_ylim( 6 , 12 )
	ax.set_title('Figure 2:  Two-sample comparison of acidity in high- vs. low-quality wines.')
	plt.show()

